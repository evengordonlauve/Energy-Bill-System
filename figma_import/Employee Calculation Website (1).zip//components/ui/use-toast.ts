
import { useToast as useToastOriginal } from "./toast";

export { useToast } from "./toast";

// This is a stub file to help with imports
// The actual implementation is already available in the project
